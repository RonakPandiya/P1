# ── pip install pandas matplotlib scikit-learn ──────────────────────────
 
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
 
# ── Dataset ──────────────────────────────────────────────────────────────
data = {
    "Study_Hours": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    "Marks":       [32, 36, 42, 48, 53, 61, 67, 72, 78, 85]
}
df = pd.DataFrame(data)
print(df.to_string(index=False))
 
# ── Model ────────────────────────────────────────────────────────────────
X = df[["Study_Hours"]]
y = df["Marks"]
 
model = LinearRegression()
model.fit(X, y)
pred = model.predict(X)
 
print(f'\nIntercept  : {model.intercept_:.2f}')
print(f'Slope      : {model.coef_[0]:.2f}')
print(f'R2 Score   : {model.score(X, y):.3f}')
 
# ── Graph ────────────────────────────────────────────────────────────────
plt.scatter(df["Study_Hours"], y, color="steelblue", label="Actual Marks")
plt.plot(df["Study_Hours"], pred, color="red", linewidth=2, label="Best-fit Line")
plt.xlabel("Study Hours")
plt.ylabel("Marks")
plt.title("Linear Regression: Study Hours vs Marks")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
