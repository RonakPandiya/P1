# ── pip install pandas matplotlib scikit-learn ──────────────────────────
 
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
 
# ── Dataset ──────────────────────────────────────────────────────────────
data = {
    "Study_Hours": [1,  2,  3,  4,  5,  6,  7,  8,  9,  10],
    "Attendance":  [45, 50, 55, 58, 62, 70, 76, 80, 88, 92],
    "Result":      [0,  0,  0,  0,  1,  1,  1,  1,  1,  1 ]
}
df = pd.DataFrame(data)
print(df.to_string(index=False))
 
# ── Model ────────────────────────────────────────────────────────────────
X = df[["Study_Hours", "Attendance"]]
y = df["Result"]
 
model = LogisticRegression()
model.fit(X, y)
 
prob  = model.predict_proba(X)[:, 1]
pred  = model.predict(X)
 
print(f'\nProbabilities   : {prob.round(2)}')
print(f'Predicted Class : {pred}')
print(f'Accuracy        : {accuracy_score(y, pred):.2f}')
print(f'Confusion Matrix:\n{confusion_matrix(y, pred)}')
 
# ── Graph ────────────────────────────────────────────────────────────────
plt.scatter(df["Study_Hours"], y, color="steelblue", zorder=5, label="Actual")
plt.plot(df["Study_Hours"], prob, color="red", marker="o", label="Pass Probability")
plt.axhline(0.5, color='gray', linestyle='--', label='Threshold 0.5')
plt.xlabel("Study Hours")
plt.ylabel("Probability / Class")
plt.title("Logistic Regression: Pass/Fail Classification")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
